Copyright (c) 2009-2013 Bitcoin Developers
Copyright (c) 2013-2014 DarkCoin/DirtyCoin Developers

What is DirtyCoin?
----------------

DirtyCoin is a lite version of Bitcoin using X11 as a proof-of-work algorithm and implmentation of Personal Backed-Asset Coin.
 - Super secure hashing algorithm: 11 rounds of scientific hashing functions (blake, bmw, groestl, jh, keccak, skein, luffa, cubehash, shavite, simd, echo)
 - GPU/CPU only mining
 - 12M Coins.
 - Block generation: 1 minutes

License
-------

DirtyCoin is released under the terms of the MIT license. See `COPYING` for more
information or see http://opensource.org/licenses/MIT.

