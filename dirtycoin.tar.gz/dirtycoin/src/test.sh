make -j 8 -f makefile.unix test_darkcoin UNIT_TEST=1
./test_darkcoin
